self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ef4e2d6efb78e9eb0bbfa17e0b55c52c",
    "url": "CNAME"
  },
  {
    "revision": "f6f9223e1a3afbefc165",
    "url": "css/Chapter.ba6859e8.css"
  },
  {
    "revision": "55a14ff2946bee2a50ca",
    "url": "css/app.e055d439.css"
  },
  {
    "revision": "abcdf25593a28dff9046",
    "url": "css/bookDetail.609040da.css"
  },
  {
    "revision": "13bf6b4e3d0343b72da7",
    "url": "css/catSort.5f873e6e.css"
  },
  {
    "revision": "80295280ff55ce88e0cf",
    "url": "css/category.d1450322.css"
  },
  {
    "revision": "0948a5466653264894ff",
    "url": "css/chunk-vendors.7a3a2db9.css"
  },
  {
    "revision": "47606dbb0ba4df1b530aa6c2e2695939",
    "url": "index.html"
  },
  {
    "revision": "f6f9223e1a3afbefc165",
    "url": "js/Chapter.99bf3735.js"
  },
  {
    "revision": "fb71ec4db06d5c5627d9",
    "url": "js/Search.7559cbc7.js"
  },
  {
    "revision": "55a14ff2946bee2a50ca",
    "url": "js/app.edd6edc6.js"
  },
  {
    "revision": "abcdf25593a28dff9046",
    "url": "js/bookDetail.a8b4c67a.js"
  },
  {
    "revision": "13bf6b4e3d0343b72da7",
    "url": "js/catSort.aea56a05.js"
  },
  {
    "revision": "80295280ff55ce88e0cf",
    "url": "js/category.91ce7fa5.js"
  },
  {
    "revision": "0948a5466653264894ff",
    "url": "js/chunk-vendors.9e43c2c2.js"
  },
  {
    "revision": "5c67b49217f12a786fbd47a46ad46154",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  }
]);