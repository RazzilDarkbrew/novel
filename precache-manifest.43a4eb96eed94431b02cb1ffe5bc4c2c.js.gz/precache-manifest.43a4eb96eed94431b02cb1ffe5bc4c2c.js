self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ef4e2d6efb78e9eb0bbfa17e0b55c52c",
    "url": "CNAME"
  },
  {
    "revision": "52c936ece5bd15cdd010",
    "url": "css/Chapter.8e34dec6.css"
  },
  {
    "revision": "5d3adfeee4963da86395",
    "url": "css/app.da8df25e.css"
  },
  {
    "revision": "b697ddb8666b45e1c05d",
    "url": "css/bookDetail.d0643573.css"
  },
  {
    "revision": "c26eeed093dceac9219b",
    "url": "css/catSort.3e696c00.css"
  },
  {
    "revision": "0a914cf9b67badcdf10f",
    "url": "css/category.303a08b4.css"
  },
  {
    "revision": "bb7e73520a8ffe432ad7",
    "url": "css/chunk-vendors.f5ac36a4.css"
  },
  {
    "revision": "5b52be10a13929c39a358a3527be8f19",
    "url": "index.html"
  },
  {
    "revision": "52c936ece5bd15cdd010",
    "url": "js/Chapter.d408a338.js"
  },
  {
    "revision": "f5700bea61a514bf9709",
    "url": "js/Search.5180d957.js"
  },
  {
    "revision": "5d3adfeee4963da86395",
    "url": "js/app.6865ff48.js"
  },
  {
    "revision": "b697ddb8666b45e1c05d",
    "url": "js/bookDetail.287fa4fe.js"
  },
  {
    "revision": "c26eeed093dceac9219b",
    "url": "js/catSort.8f3477f0.js"
  },
  {
    "revision": "0a914cf9b67badcdf10f",
    "url": "js/category.afa7e19f.js"
  },
  {
    "revision": "bb7e73520a8ffe432ad7",
    "url": "js/chunk-vendors.7f7b2b19.js"
  },
  {
    "revision": "5c67b49217f12a786fbd47a46ad46154",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  }
]);